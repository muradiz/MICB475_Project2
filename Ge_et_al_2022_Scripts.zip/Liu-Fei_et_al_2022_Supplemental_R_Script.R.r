### EXPORT PACKAGES
library(svglite)
library(writexl)

### METADATA MANIPULATION
library(tidyverse)
library(readxl)

DORMS <- read_excel("dorms_metadata.xlsx")
HISEAS <- read_excel("hiseas_metadata.xlsx")
DORMS_HISEAS_METADATA <- read_excel("dorms_hiseas_metadata.xlsx")

DORMS1 <- DORMS %>% mutate(dataset = "dorms")
HISEAS1 <- HISEAS %>% mutate(dataset = "hiseas")

DORMS1[setdiff(names(HISEAS1), names(DORMS1))] <- NA
HISEAS1[setdiff(names(DORMS1), names(HISEAS1))] <- NA

DORMS_HISEAS <- rbind(DORMS1, HISEAS1)
DORMS_HISEAS1 <- DORMS_HISEAS %>% select(`#SampleID`, dataset)

movingpictures1 <- read_tsv("moving-sample-metadata.tsv")
movingpictures2 <- movingpictures1 %>% select(1:3)
colnames(movingpictures2) <- colnames(DORMS_HISEAS1)
row_to_add <- movingpictures2[1,]

DORMS_HISEAS2 <- row_to_add %>% rbind(DORMS_HISEAS1)

write_tsv(DORMS_HISEAS2, "filtered_dorms_hiseas_metadata.tsv")
write_tsv(DORMS_HISEAS, "dorms_hiseas_metadata.tsv")

### DIFFERENTIAL ABUNDANCE ANALYSIS
# Load CRAN packages
library(tidyverse)
library(vegan)
library(ape)

# Load Bioconductor packages
library(phyloseq)
library(DESeq2)

# Helper functions
# Calculate relative abundance
calculate_relative_abundance <- function(x) x / sum(x)

# Calculate geometric mean 
calculate_gm_mean <- function(x, na.rm = TRUE) {
  exp(sum(log(x[x > 0]), na.rm = na.rm) / length(x))
}

# Set random numbers
set.seed(711)

biom_file <- import_biom(here::here("447_analysis", "table-with-taxonomy.biom"))
metadata <- import_qiime_sample_data(here::here("447_analysis","dorms_hiseas_metadata.tsv"))
tree <- read_tree_greengenes(here::here("447_analysis","tree.nwk")) %>% multi2di()
physeq <- merge_phyloseq(biom_file, metadata, tree)

# convert taxonomic rank names
colnames(tax_table(physeq)) <- c("Kingdom", "Phylum", "Class","Order", "Family",
                                 "Genus", "Species")

# ABIOTIC FILTERED
abiotic <- subset_samples(physeq, sample_type == "surface")
abiotic_total_counts <- taxa_sums(abiotic)
abiotic_relative_abundance <- calculate_relative_abundance(abiotic_total_counts)
abiotic_abundant <- abiotic_relative_abundance > 0.0005 
abiotic_abundant_taxa <- prune_taxa(abiotic_abundant, abiotic)
abundant_abiotic_genera <- tax_glom(abiotic, taxrank = "Genus")
deseq_abiotic <- phyloseq_to_deseq2(abundant_abiotic_genera, ~ dataset)
deseq_abiotic$dataset <- relevel(deseq_abiotic$dataset, ref = "hiseas")
abiotic_geo_means <- apply(counts(deseq_abiotic), 1, calculate_gm_mean)
deseq_abiotic <- estimateSizeFactors(deseq_abiotic, geoMeans = abiotic_geo_means)
deseq_abiotic <- DESeq(deseq_abiotic, fitType = "local")
abiotic_diff_abund <- results(deseq_abiotic)
alpha <- 0.05
significant_abiotic <- abiotic_diff_abund %>% as.data.frame() %>% filter(padj < alpha)
abiotic_genera_df <- as.data.frame(tax_table(abundant_abiotic_genera))
(significant_abiotic <- significant_abiotic %>% merge(abiotic_genera_df, by = "row.names") %>% arrange(padj))

top_20_abiotic <- significant_abiotic %>% head(n=20L)

ggplot(top_20_abiotic, aes(x = log2FoldChange, y = Genus)) +
  geom_bar(stat = "identity") +
  labs(title = "Differential abundant genera abiotic",
       x = expression(log[2]~fold~change),
       y = "Genus") +
  theme_bw()

ggsave("differential_abundance_genus_abiotic.svg", width = 9, height = 6)
ggsave("differential_abundance_genus_abiotic.pdf", width = 9, height = 6)

# BIOTIC FILTERED
biotic <- subset_samples(physeq, sample_type == "skin")
biotic_total_counts <- taxa_sums(biotic)
biotic_relative_abundance <- calculate_relative_abundance(biotic_total_counts)
biotic_abundant <- biotic_relative_abundance > 0.0005 
biotic_abundant_taxa <- prune_taxa(biotic_abundant, biotic)
abundant_biotic_genera <- tax_glom(biotic, taxrank = "Genus")
deseq_biotic <- phyloseq_to_deseq2(abundant_biotic_genera, ~ dataset)
deseq_biotic$dataset <- relevel(deseq_biotic$dataset, ref = "hiseas")
biotic_geo_means <- apply(counts(deseq_biotic), 1, calculate_gm_mean)
deseq_biotic <- estimateSizeFactors(deseq_biotic, geoMeans = biotic_geo_means)
deseq_biotic <- DESeq(deseq_biotic, fitType = "local")
biotic_diff_abund <- results(deseq_biotic)
alpha <- 0.05
significant_biotic <- biotic_diff_abund %>% as.data.frame() %>% filter(padj < alpha)
biotic_genera_df <- as.data.frame(tax_table(abundant_biotic_genera))
(significant_biotic <- significant_biotic %>% merge(biotic_genera_df, by = "row.names") %>% arrange(padj))

top_20_biotic <- significant_biotic %>% head(n=20L)

ggplot(top_20_biotic, aes(x = log2FoldChange, y = Genus)) +
  geom_bar(stat = "identity") +
  labs(title = "Differential abundant genera biotic",
       x = expression(log[2]~fold~change),
       y = "Genus") +
  theme_bw()

ggsave("differential_abundance_genus_biotic.svg", width = 9, height = 6)
ggsave("differential_abundance_genus_biotic.pdf", width = 9, height = 6)

### RELATIVE ABUNDANCE ANALYSIS
library(tidyverse)
library(microeco)
library(file2meco)
library(randomForest)
library(cowplot)

# set.seed is used to fix the random number generation to make the results repeatable
set.seed(711)
theme_set(theme_bw(base_size=18))
calculate_relative_abundance <- function(x) x/sum(x)

# create meco object
(meco_data<-qiime2meco(
  ASV_data=here::here("447_analysis","filtered-table.qza"),
  phylo_tree=here::here("447_analysis","rooted-tree.qza"),
  taxonomy_data=here::here("447_analysis","taxonomy.qza"),
  sample_data = here::here("447_analysis","filtered_dorms_hiseas_metadata.tsv")))

# ABIOTIC FILTERED
meco_abiotic_DA <- clone(meco_data)
meco_abiotic_DA$sample_table <- meco_abiotic_DA$sample_table %>% filter(`sample_type` == "surface")
meco_abiotic_DA$tidy_dataset()
meco_abiotic_DA$cal_abund()
DA_abiotic <- trans_diff$new(dataset = meco_abiotic_DA, method = "rf", group = "dataset", alpha = 0.01, rf_taxa_level = "Genus")
plots_abiotic <- DA_abiotic$plot_diff_abund(use_number = 1:20, only_abund_plot = FALSE)
plot_grid(plots_abiotic$p1, plots_abiotic$p2)
ggsave("Differential_Abundance_Abiotic.svg", width = 12, height = 8)

# BIOTIC FILTERED
meco_biotic_DA <- clone(meco_data)
meco_biotic_DA$sample_table <- meco_biotic_DA$sample_table %>% filter(`sample_type` == "skin")
meco_biotic_DA$tidy_dataset()
meco_biotic_DA$cal_abund()
DA_biotic <- trans_diff$new(dataset = meco_biotic_DA, method = "rf", group = "dataset", alpha = 0.01, rf_taxa_level = "Genus")
plots_biotic <- DA_biotic$plot_diff_abund(use_number = 1:20, only_abund_plot = FALSE)
plot_grid(plots_biotic$p1, plots_biotic$p2)
ggsave("Differential_Abundance_Biotic.svg", width = 12, height = 8)